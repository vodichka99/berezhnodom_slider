<template>
  <swiper>
    <swiper-slide
      v-for="(content, index) in slidesContent"
      :data-title="content.name"
      :key="index"
    >
      <div class="darknes">
        <div
          class="background"
          :style="`background-image: url(${content.background});`"
        ></div>
      </div>
      <div class="slider-content">
        <div class="slider-content__wrapper">
          <h2>{{ content.name }}</h2>
          <p>
            {{ content.descr }}
          </p>
          <button onclick="alert('Bingo!')">подробнее о проекте</button>
        </div>
      </div>
    </swiper-slide>
  </swiper>
</template>
<script>

import SwiperCore, { Navigation, Pagination, Scrollbar, A11y } from "swiper";

// Import Swiper Vue.js components
import { Swiper, SwiperSlide } from "swiper/vue";

// Import Swiper styles
import "swiper/swiper.scss";
import "swiper/components/navigation/navigation.scss";
import "swiper/components/pagination/pagination.scss";
import "swiper/components/scrollbar/scrollbar.scss";

// install Swiper modules
SwiperCore.use([Navigation, Pagination, Scrollbar, A11y]);

export default {
  components: {
    Swiper,
    SwiperSlide,
  },
  data() {
    return {
      slidesContent: [
        {
          name: "Икс-Рей",
          descr:
            "Проект коттеджа для круглогодичного проживания выполненный в современном стиле Модерн",
          background:
            "https://berezhnodom.ru/upload/iblock/64c/64c03035e75ad3201b43f13b72401c7e.jpg",
        },
        {
          name: "Супер проект",
          descr:
            "Проект коттеджа для круглогодичного проживания выполненный в современном стиле Модерн",
          background:
            "https://berezhnodom.ru/upload/iblock/39b/39b8558d62857da99da59fe57961ea74.jpg",
        },
        {
          name: "Икс-Рей",
          descr:
            "Проект коттеджа для круглогодичного проживания выполненный в современном стиле Модерн",
          background:
            "https://berezhnodom.ru/upload/iblock/6c9/6c9538ae1202a37e3225064f80e6d09d.jpg",
        },
        {
          name: "Икс-Рей",
          descr:
            "Проект коттеджа для круглогодичного проживания выполненный в современном стиле Модерн",
          background: "https://swiperjs.com/demos/images/nature-4.jpg",
        },
        {
          name: "Икс-Рей",
          descr:
            "Проект коттеджа для круглогодичного проживания выполненный в современном стиле Модерн",
          background: "https://swiperjs.com/demos/images/nature-5.jpg",
        },
        {
          name: "Икс-Рей",
          descr:
            "Проект коттеджа для круглогодичного проживания выполненный в современном стиле Модерн",
          background: "https://swiperjs.com/demos/images/nature-6.jpg",
        },
        {
          name: "Икс-Рей",
          descr:
            "Проект коттеджа для круглогодичного проживания выполненный в современном стиле Модерн",
          background: "https://swiperjs.com/demos/images/nature-7.jpg",
        },
        {
          name: "Икс-Рей",
          descr:
            "Проект коттеджа для круглогодичного проживания выполненный в современном стиле Модерн",
          background: "https://swiperjs.com/demos/images/nature-8.jpg",
        },
      ],
    };
  },
  mounted() {},
};
</script>

<style lang="scss">
#app{
  width: 100%;
  height: 100%;
}
html,
body {
  position: relative;
  height: 100%;
  margin: 0;
  padding: 0;
}

body {
  background: #eee;
  font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
  font-size: 14px;
  color: #000;
  margin: 0;
  padding: 0;
}

.swiper-container {
  width: 100%;
  height: 100%;
  /*padding-top: 50px;
        padding-bottom: 50px;*/
}

.swiper-slide {
  background-position: center;
  background-size: cover;
  width: 100%;
  height: 100%;
}

.swiper-slide img {
  display: block;
  width: 100%;
  height: 100%;
}

.darknes {
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 100;
}
.background {
  position: absolute;
  z-index: -1;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  background-repeat: no-repeat;
  background-size: cover;
}

.slider-content {
  position: absolute;
  z-index: 101;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  background-repeat: no-repeat;
  background-size: cover;
}

.swiper-container-vertical > .swiper-pagination-bullets {
  right: auto;
}
.swiper-pagination {
  right: 0;
  left: 70px;
  right: auto;
  z-index: 9999;
}

.swiper-container-vertical
  > .swiper-pagination-bullets
  .swiper-pagination-bullet {
  cursor: pointer;
  color: white;
  width: 150px;
  background: none;
  margin-bottom: 30px;
  text-align: left;
}

.swiper-container-vertical
  > .swiper-pagination-bullets
  .swiper-pagination-bullet {
  opacity: 0.5;
}

.swiper-container-vertical
  > .swiper-pagination-bullets
  .swiper-pagination-bullet-active {
  opacity: 1;
}

.swiper-container-vertical > .swiper-scrollbar {
  right: auto;
  left: 40px;
  height: 38%;
  top: 50%;
  transform: translateY(-50%);
  width: 2px;
}

.swiper-scrollbar-drag {
  background-color: white;
}

.slider-content__wrapper {
  width: 50%;
  margin: auto;
  position: relative;
  top: 30%;
  transform: translateY(-30%);
  z-index: 101;
  text-align: center;
}

.slider-content__wrapper > h2 {
  color: white;
  padding: 0;
  margin: 10px 0;
  font-size: 64px;
  font-weight: 700;
  // text-shadow: 2px 4px 3px rgb(0 0 0 / 30%);
}
.slider-content__wrapper > p {
  color: white;
  font-size: 18px;
  line-height: 30px;
  width: 80%;
  margin: auto;
}

.slider-content__wrapper > button {
  margin-top: 20%;
  background: transparent;
  border: 1px solid white;
  padding: 10px 20px;
  color: white;
  cursor: pointer;
  transition: all 0.3s ease;
}
.slider-content__wrapper > button:hover {
  background-color: white;
  color: black;
  border-color: black;
}

.swiper-button-next {
  left: auto;
  right: 100px;
  background: #000000 !important;
}

.swiper-button-prev {
  top: 40%;
  left: auto;
  right: 100px;
}

.swiper-button-next,
.swiper-button-prev {
  width: 54px;
  height: 54px;
  background: #ffffff;
  transform: rotate(-90deg);
  transition: all 0.3s ease;
}

.swiper-button-prev:after,
.swiper-container-rtl .swiper-button-next:after,
.swiper-button-next:after,
.swiper-container-rtl .swiper-button-prev:after {
  content: none;
}
</style>
